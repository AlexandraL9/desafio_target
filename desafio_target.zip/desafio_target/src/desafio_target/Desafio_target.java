package desafio_target;

import java.util.Scanner;
import java.util.Random;

public class Desafio_target {
    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);
        
        //Estágio Ribeirão Preto 
        
        //Parte 1
        
        int indice = 13, soma = 0, k = 0;
        
        while (k<indice){
            k = k + 1;
            soma = soma + k;
        }
        
        System.out.println("1 - A soma é igual a " + soma);
        System.out.println();
        
        //Parte 2
     
        int n1 = 0, n2 = 1;
        
        System.out.print("Digite um número: ");
        int numero = input.nextInt();
        input.nextLine();
        
        boolean pertence = false;
        while (n2 <= numero) {
            if (n2 == numero) {
                pertence = true;
                break;
            }else{
                int soma1 = n1 + n2;
                n1 = n2;
                n2 = soma1;
            }
        }

        if (pertence) {
            System.out.println(numero + " pertence a sequência de Fibonacci.");
        } else {
            System.out.println(numero + " não pertence a sequência de Fibonacci.");
        }
        
        System.out.println();
        
        //Parte 3
        
        // Sequência a)
        System.out.println("a) 1, 3, 5, 7, 9");
        
        // Sequência b)
        System.out.print("b) 2, 4, 8, 16, 32, 64, ");
        for (int i = 6; i < 7; i++) {
            int nextElement = (int) Math.pow(2, i + 1);
            System.out.print(nextElement + ", ");
        }
        System.out.println();
        
        // Sequência c)
        System.out.print("c) 0, 1, 4, 9, 16, 25, 36, ");
        for (int i = 7; i < 8; i++) {
            int nextElement = i * i;
            System.out.print(nextElement + ", ");
        }
        System.out.println();
        
        // Sequência d)
        System.out.print("d) 4, 16, 36, 64, ");
        for (int i = 5; i < 6; i++) {
            int nextElement = i * i * 4;
            System.out.print(nextElement + ", ");
        }
        System.out.println();
        
        // Sequência e)
        System.out.print("e) 1, 1, 2, 3, 5, 8, ");
        int prev = 5, prevPrev = 3;
        for (int i = 6; i < 7; i++) {
            int nextElement = prev + prevPrev;
            System.out.print(nextElement + ", ");
            prevPrev = prev;
            prev = nextElement;
        }
        System.out.println();
        
        // Sequência f)
        System.out.print("f) 2, 10, 12, 16, 17, 18, 19, ");
        for (int i = 20; i <= 99; i++) {
            boolean[] digits = new boolean[10];
            int num = i;
            while (num > 0) {
                digits[num % 10] = true;
                num /= 10;
            }
            boolean allDigitsPresent = true;
            for (boolean digit : digits) {
                if (!digit) {
                    allDigitsPresent = false;
                    break;
                }
            }
            if (allDigitsPresent) {
                System.out.print(i + ", ");
                break;
            }
        }
        
        System.out.println();
        
        //Parte 4
        
        int numInterruptores = 3;
        int numLampadas = 3;

        boolean[] lampadasAcesas = new boolean[numLampadas];
        boolean[] lampadasQuentes = new boolean[numLampadas];
        
        System.out.println();

        Random random = new Random();
        for (int i = 0; i < numLampadas; i++) {
            lampadasAcesas[i] = random.nextBoolean(); // true representa a lâmpada acesa e false representa a lâmpada apagada
            lampadasQuentes[i] = random.nextBoolean(); // true representa a lâmpada quente e false representa a lâmpada fria
        }

        int interruptorLigado1 = -1;
        int interruptorLigado2 = -1;

        // Primeira visita à sala
        for (int i = 0; i < numInterruptores - 1; i++) {
            // Ligar dois interruptores e deixar um desligado
            if (interruptorLigado1 == -1) {
                interruptorLigado1 = i;
            } else if (interruptorLigado2 == -1) {
                interruptorLigado2 = i;
            }
            System.out.println("Ligando o interruptor " + i);
        }

        // Segunda visita à sala
        for (int i = 0; i < numInterruptores; i++) {
            // Desligar um interruptor e deixar os outros na mesma posição
            if (i != interruptorLigado1 && i != interruptorLigado2) {
                System.out.println("Desligando o interruptor " + i);
            }
        }

        // Verificando o resultado
        for (int i = 0; i < numLampadas; i++) {
            if (lampadasAcesas[i]) {
                System.out.println("O interruptor " + (i + 1) + " controla a lâmpada " + (i + 1) + " que está acesa.");
            } else {
                if (lampadasQuentes[i]) {
                    System.out.println("O interruptor " + (interruptorLigado2 + 1) + " controla a lâmpada " + (i + 1) + " que está apagada e quente.");
                } else {
                    System.out.println("O interruptor " + (interruptorLigado1 + 1) + " controla a lâmpada " + (i + 1) + " que está apagada e fria.");
                }
            }
        }
        
        System.out.println();
        
       //Parte 5
       
       System.out.print("Digite uma string: ");
        String original = input.nextLine();

        String invertida = inverterString(original);

        System.out.println("String original: " + original);
        System.out.println("String invertida: " + invertida);
    }

    public static String inverterString(String str) {
        // Convertendo a string para um array de caracteres
        char[] caracteres = str.toCharArray();

        // Invertendo os caracteres
        for (int i = 0; i < caracteres.length / 2; i++) {
            char temp = caracteres[i];
            caracteres[i] = caracteres[caracteres.length - i - 1];
            caracteres[caracteres.length - i - 1] = temp;
        }

        // Construindo a string invertida
        StringBuilder invertida = new StringBuilder();
        for (char c : caracteres) {
            invertida.append(c);
        }

        return invertida.toString();
    } 
}
